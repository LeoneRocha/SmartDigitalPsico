import { NgModule, ModuleWithProviders, SkipSelf, Optional } from '@angular/core';
import { Configuration } from './configuration';
import { HttpClient } from '@angular/common/http';


import { ApplicationConfigSettingService } from './api/applicationConfigSetting.service';
import { ApplicationLanguageService } from './api/applicationLanguage.service';
import { AuthService } from './api/auth.service';
import { GenderService } from './api/gender.service';
import { GlobalizationCulturesService } from './api/globalizationCultures.service';
import { GlobalizationTimeZonesService } from './api/globalizationTimeZones.service';
import { MedicalService } from './api/medical.service';
import { MedicalFileService } from './api/medicalFile.service';
import { OfficeService } from './api/office.service';
import { PatientService } from './api/patient.service';
import { PatientAdditionalInformationService } from './api/patientAdditionalInformation.service';
import { PatientFileService } from './api/patientFile.service';
import { PatientHospitalizationInformationService } from './api/patientHospitalizationInformation.service';
import { PatientMedicationInformationService } from './api/patientMedicationInformation.service';
import { PatientNotificationMessageService } from './api/patientNotificationMessage.service';
import { PatientRecordService } from './api/patientRecord.service';
import { RoleGroupService } from './api/roleGroup.service';
import { SpecialtyService } from './api/specialty.service';
import { UserService } from './api/user.service';

@NgModule({
  imports:      [],
  declarations: [],
  exports:      [],
  providers: [
    ApplicationConfigSettingService,
    ApplicationLanguageService,
    AuthService,
    GenderService,
    GlobalizationCulturesService,
    GlobalizationTimeZonesService,
    MedicalService,
    MedicalFileService,
    OfficeService,
    PatientService,
    PatientAdditionalInformationService,
    PatientFileService,
    PatientHospitalizationInformationService,
    PatientMedicationInformationService,
    PatientNotificationMessageService,
    PatientRecordService,
    RoleGroupService,
    SpecialtyService,
    UserService ]
})
export class ApiModule {
    public static forRoot(configurationFactory: () => Configuration): ModuleWithProviders<ApiModule> {
        return {
            ngModule: ApiModule,
            providers: [ { provide: Configuration, useFactory: configurationFactory } ]
        };
    }

    constructor( @Optional() @SkipSelf() parentModule: ApiModule,
                 @Optional() http: HttpClient) {
        if (parentModule) {
            throw new Error('ApiModule is already loaded. Import in your base AppModule only.');
        }
        if (!http) {
            throw new Error('You need to import the HttpClientModule in your AppModule! \n' +
            'See also https://github.com/angular/angular/issues/20575');
        }
    }
}
